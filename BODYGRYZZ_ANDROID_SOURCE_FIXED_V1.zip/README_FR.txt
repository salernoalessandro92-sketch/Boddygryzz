BODYGRYZZ — projet Android natif (base alpha)

CE QUI EST INCLUS
- Projet Android Kotlin + Jetpack Compose, thème noir/rouge.
- Navigation : HOME, BEAST FUEL, IRON WORKOUT, BODY SCAN, EVOLUTION.
- Module nutrition fonctionnel de base : ajout/suppression d'aliments, portions, kcal, protéines, glucides, lipides, totaux journaliers, stockage local Room.
- Dépendance Health Connect et lecteur de données pour pas et calories actives.
- Déclaration des autorisations Health Connect pour activité, poids, masse grasse, masse maigre et métabolisme basal.

CE QUI N'EST PAS ENCORE TERMINÉ
- Ce ZIP est le CODE SOURCE, pas un APK installable.
- La synchronisation Health Connect doit être testée sur un appareil réel avec les autorisations réellement accordées.
- Les écrans IRON, BODY et EVOLUTION sont des bases d'interface, pas des modules complets.
- Le scan de code-barres, base alimentaire, photos, sauvegarde cloud, calculs avancés et synchronisation en arrière-plan restent à développer.
- Les données de composition corporelle ne seront disponibles que si une application source les écrit dans Health Connect et si le type est pris en charge sur le téléphone.
- Samsung Health Data SDK peut demander un accès partenaire séparé ; cette base utilise Health Connect.

COMMENT COMPILER
1. Ouvrir le dossier dans Android Studio sur un ordinateur.
2. Laisser Gradle synchroniser les dépendances.
3. Compiler et installer sur un appareil Android compatible.
4. Dans l'application, appuyer sur CONNECTER HEALTH CONNECT et accepter les autorisations voulues.

PROFIL INITIAL
- Objectif protéines : 180 g/jour.
- Créatine : 6 g/jour (suivi séparé, non compté comme protéine).
- Shaker connu : 26 g de protéines (ajouter comme aliment dans le journal).
- Objectifs pompes/cardio : à intégrer dans le module entraînement.
- Poids historique connu : environ 80 kg, à confirmer avant d'en faire une valeur de départ.

CONFIDENTIALITÉ
Les repas sont enregistrés localement dans la base Room du téléphone. Aucun compte ni serveur distant n'est configuré.

COMPILATION DANS LE CLOUD DEPUIS UN TELEPHONE (sans Android Studio)
1. Creer un compte GitHub si necessaire, puis un nouveau depot (repository) vide nomme BODYGRYZZ.
2. Importer dans ce depot tous les fichiers et dossiers contenus dans ce projet (pas le ZIP lui-meme).
3. Ouvrir l'onglet Actions du depot. Autoriser les workflows si GitHub le demande.
4. Le workflow Android APK se lance apres l'envoi sur main/master. Il peut aussi etre lance depuis Actions > BODYGRYZZ Android APK > Run workflow.
5. Ouvrir l'execution terminee avec une coche verte, descendre a Artifacts et telecharger BODYGRYZZ-debug-APK.
6. Extraire le ZIP de l'artifact : il contient app-debug.apk. Ouvrir ce fichier sur le Samsung pour lancer l'installation. Android peut demander d'autoriser temporairement l'installation depuis cette source.

IMPORTANT : cette automatisation de compilation n'a pas encore ete executee. Le projet est une alpha non testee; une erreur de compilation peut apparaitre et devra etre corrigee avant installation. L'APK debug n'est pas une version publiee sur Google Play.
