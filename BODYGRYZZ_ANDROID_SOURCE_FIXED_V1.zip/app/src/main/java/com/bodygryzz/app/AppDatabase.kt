package com.bodygryzz.app

import android.content.Context
import androidx.room.*

@Dao
interface FoodDao {
    @Query("SELECT * FROM food_entries ORDER BY createdAt DESC")
    suspend fun all(): List<FoodEntry>
    @Insert suspend fun insert(entry: FoodEntry)
    @Delete suspend fun delete(entry: FoodEntry)
}

@Database(entities = [FoodEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun foodDao(): FoodDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "bodygryzz.db").build().also { INSTANCE = it }
        }
    }
}
