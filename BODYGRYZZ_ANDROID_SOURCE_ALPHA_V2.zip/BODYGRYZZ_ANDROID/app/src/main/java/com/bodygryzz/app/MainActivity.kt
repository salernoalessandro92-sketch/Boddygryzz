package com.bodygryzz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContract
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.health.connect.client.permission.PermissionController
import kotlinx.coroutines.launch

private val Black = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFED1C24)
private val Grey = Color(0xFFAAAAAA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val health = HealthConnectReader(this)
        setContent {
            var tab by remember { mutableStateOf("HOME") }
            var foods by remember { mutableStateOf(emptyList<FoodEntry>()) }
            var steps by remember { mutableStateOf<Long?>(null) }
            var activeKcal by remember { mutableStateOf<Double?>(null) }
            var healthMessage by remember { mutableStateOf("Connexion Health Connect non autorisée") }
            val scope = rememberCoroutineScope()
            val permissionLauncher = rememberLauncherForActivityResult(
                PermissionController.createRequestPermissionResultContract()
            ) { granted ->
                scope.launch {
                    if (granted.containsAll(health.permissions)) {
                        steps = runCatching { health.todaySteps() }.getOrNull()
                        activeKcal = runCatching { health.todayActiveCalories() }.getOrNull()
                        healthMessage = "Health Connect autorisé"
                    } else healthMessage = "Certaines autorisations sont refusées"
                }
            }
            LaunchedEffect(Unit) { foods = db.foodDao().all() }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Red, background = Black, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Scaffold(
                    containerColor = Black,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF101010), contentColor = Color.White) {
                            listOf("HOME", "FUEL", "IRON", "BODY", "STATS").forEach { item ->
                                NavigationBarItem(
                                    selected = tab == item, onClick = { tab = item },
                                    icon = { Icon(
                                        when(item) { "FUEL" -> Icons.Default.Restaurant; "IRON" -> Icons.Default.FitnessCenter; "BODY" -> Icons.Default.MonitorWeight; "STATS" -> Icons.Default.QueryStats; else -> Icons.Default.Bolt },
                                        contentDescription = item
                                    ) },
                                    label = { Text(item, fontWeight = FontWeight.Black) },
                                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Red, indicatorColor = Color(0xFF3A090B), unselectedIconColor = Grey, unselectedTextColor = Grey)
                                )
                            }
                        }
                    }
                ) { padding ->
                    Column(Modifier.fillMaxSize().background(Black).padding(padding).padding(16.dp)) {
                        Text("BODYGRYZZ", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                        Text("BEAST MODE // NO EXCUSES", color = Red, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(14.dp))
                        when(tab) {
                            "HOME" -> HomeScreen(steps, activeKcal, healthMessage) {
                                permissionLauncher.launch(health.permissions)
                            }
                            "FUEL" -> FuelScreen(foods, { foods = it }, db)
                            "IRON" -> StaticScreen("IRON WORKOUT", "Journal d'exercices, séries, répétitions, charges et records personnels.")
                            "BODY" -> StaticScreen("BODY SCAN", "Poids, masse grasse, masse maigre, masse musculaire et eau corporelle. Les valeurs seront affichées uniquement si Health Connect les fournit.")
                            else -> StaticScreen("EVOLUTION", "Historique, tendances, objectifs et photos de progression.")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(steps: Long?, kcal: Double?, status: String, connect: () -> Unit) {
    Text("TABLEAU DE COMBAT", color = Grey, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MetricCard("PAS", steps?.toString() ?: "—", Modifier.weight(1f))
        MetricCard("KCAL ACTIVES", kcal?.toInt()?.toString() ?: "—", Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MetricCard("PROTÉINES", "180 g", Modifier.weight(1f))
        MetricCard("CRÉATINE", "6 g", Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))
    Text("SYNCHRONISATION", color = Red, fontWeight = FontWeight.Black)
    Text(status, color = Grey)
    Spacer(Modifier.height(8.dp))
    Button(onClick = connect, colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Sync, null); Spacer(Modifier.width(8.dp)); Text("CONNECTER HEALTH CONNECT", fontWeight = FontWeight.Black)
    }
    Text("Les données affichées dépendent des autorisations accordées et des mesures réellement enregistrées dans Health Connect.", color = Grey, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(5.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Grey, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
            Text(value, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun FuelScreen(entries: List<FoodEntry>, update: (List<FoodEntry>) -> Unit, db: AppDatabase) {
    var name by remember { mutableStateOf("") }
    var grams by remember { mutableStateOf("100") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val totalKcal = entries.sumOf { it.calories }
    val totalProtein = entries.sumOf { it.protein }
    val totalCarbs = entries.sumOf { it.carbs }
    val totalFat = entries.sumOf { it.fat }

    Text("BEAST FUEL // NUTRITION", color = Red, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("KCAL", totalKcal.toInt().toString(), Modifier.weight(1f))
        MetricCard("PROTÉINES", "${totalProtein.toInt()} / 180 g", Modifier.weight(1f))
    }
    Spacer(Modifier.height(6.dp))
    Text("GLUCIDES ${totalCarbs.toInt()} g   •   LIPIDES ${totalFat.toInt()} g", color = Grey)
    LinearProgressIndicator(progress = { (totalProtein / 180.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Red, trackColor = Panel)
    Spacer(Modifier.height(14.dp))
    Text("AJOUTER UN ALIMENT (VALEURS POUR LA PORTION SAISIE)", color = Color.White, fontWeight = FontWeight.Black)
    OutlinedTextField(name, { name = it }, label = { Text("Aliment / repas") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(grams, { grams = it }, label = { Text("Quantité (g)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(kcal, { kcal = it }, label = { Text("Kcal") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
        OutlinedTextField(protein, { protein = it }, label = { Text("Protéines g") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(carbs, { carbs = it }, label = { Text("Glucides g") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
        OutlinedTextField(fat, { fat = it }, label = { Text("Lipides g") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
    }
    Button(onClick = {
        if (name.isNotBlank() && kcal.toDoubleOrNull() != null && protein.toDoubleOrNull() != null) {
            val entry = FoodEntry(name = name, grams = grams.toDoubleOrNull() ?: 0.0, calories = kcal.toDouble(), protein = protein.toDouble(), carbs = carbs.toDoubleOrNull() ?: 0.0, fat = fat.toDoubleOrNull() ?: 0.0)
            scope.launch { db.foodDao().insert(entry); update(db.foodDao().all()) }
            name = ""; kcal = ""; protein = ""; carbs = ""; fat = ""
        }
    }, colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.fillMaxWidth()) {
        Text("AJOUTER AU JOURNAL", fontWeight = FontWeight.Black)
    }
    Spacer(Modifier.height(12.dp))
    Text("JOURNAL ALIMENTAIRE", color = Red, fontWeight = FontWeight.Black)
    LazyColumn {
        items(entries) { item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("${item.name} • ${item.grams.toInt()} g", fontWeight = FontWeight.Bold)
                    Text("${item.calories.toInt()} kcal  |  P ${item.protein} g  G ${item.carbs} g  L ${item.fat} g", color = Grey, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { scope.launch { db.foodDao().delete(item); update(db.foodDao().all()) } }) { Icon(Icons.Default.Delete, null, tint = Red) }
            }
            HorizontalDivider(color = Color.DarkGray)
        }
    }
}

@Composable
private fun StaticScreen(title: String, description: String) {
    Text(title, color = Red, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
    Spacer(Modifier.height(8.dp))
    Text(description, color = Grey)
    Spacer(Modifier.height(12.dp))
    Text("Module prévu dans cette base de développement. Les fonctions non encore implémentées ne sont pas présentées comme opérationnelles.", color = Grey, style = MaterialTheme.typography.bodySmall)
}
